'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const core = require('./lib/core');
const CFG = require('./config.json');

let win = null;
let data = { mode: 'join', installed: {}, sessionActive: false, gamePath: '', pseudo: '', lastUpdate: '' };
let manifest = null;
let playing = false;
let busy = false;
let booted = false;
let quitWhenDone = false;
let monitor = null;
let pushTimer = null;
let updating = false;
const ui = { update: null, error: null, mods: [], progress: null, ready: false, server: null, serverChecked: false };

const dataFile = () => path.join(app.getPath('userData'), 'data.json');

function loadData() {
  try { Object.assign(data, JSON.parse(fs.readFileSync(dataFile(), 'utf8'))); } catch (_) { /* première fois */ }
  data.mode = data.mode === 'session' ? 'session' : 'join';
  if (!data.installed || typeof data.installed !== 'object') data.installed = {};
}

function saveData() {
  try {
    fs.mkdirSync(path.dirname(dataFile()), { recursive: true });
    const tmp = dataFile() + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, dataFile());
  } catch (_) { /* non bloquant */ }
}

function snapshot() {
  const p = data.gamePath ? core.paths(data.gamePath) : null;
  const pending = ui.mods.filter((m) => m.status !== 'ok');
  return {
    ready: ui.ready,
    error: ui.error,
    gamePath: data.gamePath || '',
    gameOk: !!(p && fs.existsSync(p.exe)),
    modsDir: p ? p.modsDir : '',
    mode: data.mode,
    version: app.getVersion(),
    update: ui.update ? { version: ui.update.version, size: ui.update.size } : null,
    updating,
    pseudo: data.pseudo || '',
    lastUpdate: data.lastUpdate || '',
    playing,
    busy,
    mods: ui.mods,
    pending: pending.length,
    pendingBytes: pending.reduce((a, m) => a + m.size, 0),
    hasManifest: !!manifest,
    news: manifest && manifest.news ? manifest.news : null,
    progress: ui.progress,
    server: ui.server,
    serverChecked: ui.serverChecked,
    discordSet: !/REMPLACER/i.test(CFG.discordUrl),
    args: CFG.launchArgs,
  };
}

function push(now) {
  if (!win || win.isDestroyed()) return;
  if (now) { clearTimeout(pushTimer); pushTimer = null; win.webContents.send('state', snapshot()); return; }
  if (pushTimer) return;
  pushTimer = setTimeout(() => { pushTimer = null; if (win && !win.isDestroyed()) win.webContents.send('state', snapshot()); }, 120);
}

async function computeMods() {
  if (!manifest) { ui.mods = []; return; }
  const p = data.gamePath ? core.paths(data.gamePath) : null;
  const out = [];
  for (const m of manifest.mods) {
    let status = 'new';
    if (p) status = await core.statusOf(p.modsDir, m, data.installed);
    out.push({ name: m.name, version: m.version, size: m.size, status });
  }
  ui.mods = out;
  saveData();
}

async function refresh() {
  ui.error = null;
  try {
    manifest = await core.fetchManifest(CFG.manifestUrl + '?t=' + Date.now(), { allowedPrefix: CFG.allowedPrefix });
  } catch (e) {
    manifest = null;
    ui.error = 'Impossible de lire la liste des mods sur GitHub. Vérifiez votre connexion.';
  }
  await computeMods();
  push(true);
}

async function cleanup() {
  if (data.gamePath) {
    const p = core.paths(data.gamePath);
    const names = new Set([...Object.keys(data.installed), ...(manifest ? manifest.mods.map((m) => m.name) : [])]);
    await core.removeMods(p.modsDir, [...names]);
  }
  data.installed = {};
  data.sessionActive = false;
  saveData();
}

async function onGameEnded() {
  playing = false;
  ui.progress = null;
  if (data.sessionActive) await cleanup();
  await computeMods();
  push(true);
  if (quitWhenDone) app.quit();
}

function startMonitor() {
  clearInterval(monitor);
  let seen = false;
  let miss = 0;
  const t0 = Date.now();
  monitor = setInterval(async () => {
    const run = await core.isRunning(CFG.gameExe);
    if (run) { seen = true; miss = 0; return; }
    miss++;
    if ((seen && miss >= 2) || (!seen && Date.now() - t0 > 120000)) {
      clearInterval(monitor);
      await onGameEnded();
    }
  }, 4000);
}

let polling = false;
let srvPort = null;
async function pollServer() {
  if (polling) return;
  polling = true;
  try {
    ui.server = await core.queryServer(CFG.serverHost, CFG.serverPorts, 2000, srvPort);
    srvPort = ui.server ? ui.server.port : null;
  } catch (_) { ui.server = null; srvPort = null; }
  ui.serverChecked = true;
  polling = false;
  push();
}

async function checkUpdate() {
  try {
    const txt = await core.fetchText(CFG.updateUrl, { allowedPrefix: CFG.allowedPrefix });
    const info = core.parseVersionInfo(txt, { allowedPrefix: CFG.allowedPrefix });
    ui.update = core.cmpVer(info.version, app.getVersion()) > 0 ? info : null;
  } catch (_) { /* pas de réseau ou pas encore publié : on ne bloque rien */ }
  push(true);
}

function writeUpdater(dir) {
  const bat = path.join(dir, 'maj-launcher.bat');
  // Les chemins passent par des variables d'environnement (accents et espaces sans risque)
  fs.writeFileSync(bat, [
    '@echo off',
    'set N=0',
    ':retry',
    'ping -n 2 127.0.0.1 >nul',
    'move /Y "%PP_SRC%" "%PP_DST%" >nul 2>&1',
    'if not errorlevel 1 goto done',
    'set /a N+=1',
    'if %N% LSS 40 goto retry',
    ':done',
    'start "" "%PP_DST%"',
    '(goto) 2>nul & del "%~f0"',
    '',
  ].join('\r\n'));
  return bat;
}

async function doUpdateLauncher() {
  if (!ui.update || updating || busy || playing) return;
  const target = process.env.PORTABLE_EXECUTABLE_FILE;
  if (!target || process.platform !== 'win32') {
    ui.error = 'Mise à jour automatique impossible ici. Téléchargez le nouvel exe sur GitHub (Releases).';
    push(true);
    return;
  }
  updating = true;
  ui.error = null;
  push(true);
  const dir = path.join(app.getPath('userData'), 'update');
  const file = path.join(dir, 'ParadisPerdu-Launcher.new.exe');
  try {
    fs.mkdirSync(dir, { recursive: true });
    try { fs.unlinkSync(file); } catch (_) { /* rien à retirer */ }
    await core.downloadFile(ui.update.url, file, {
      allowedPrefix: CFG.allowedPrefix,
      expectedSha: ui.update.sha256,
      expectedSize: ui.update.size,
      onProgress: (got, total) => {
        ui.progress = { pct: Math.min(100, Math.round((got / (total || ui.update.size)) * 100)), msg: 'Téléchargement du launcher v' + ui.update.version };
        push();
      },
    });
    ui.progress = { pct: 100, msg: 'Installation et redémarrage…' };
    push(true);
    const bat = writeUpdater(dir);
    const child = spawn(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', '"' + bat + '"'], {
      detached: true, stdio: 'ignore', windowsHide: true, windowsVerbatimArguments: true,
      env: { ...process.env, PP_SRC: file, PP_DST: target },
    });
    child.unref();
    setTimeout(() => app.exit(0), 600);
  } catch (e) {
    updating = false;
    ui.progress = null;
    try { fs.unlinkSync(file); } catch (_) { /* rien */ }
    ui.error = 'Mise à jour du launcher interrompue : ' + e.message;
    push(true);
  }
}

async function boot() {
  checkUpdate();
  setInterval(checkUpdate, 30 * 60 * 1000);
  pollServer();
  setInterval(pollServer, (CFG.serverRefreshSeconds || 10) * 1000);
  if (!data.gamePath || !core.normalizeGameRoot(data.gamePath)) {
    data.gamePath = (await core.detectGame()) || '';
    saveData();
  }
  if (data.sessionActive) {
    if (await core.isRunning(CFG.gameExe)) { playing = true; startMonitor(); } else { await cleanup(); }
  }
  await refresh();
  ui.ready = true;
  push(true);
}

async function doUpdate() {
  if (ui.update || updating || busy || playing || !manifest || !data.gamePath) return;
  busy = true;
  ui.error = null;
  push(true);
  const p = core.paths(data.gamePath);
  try {
    fs.mkdirSync(p.modsDir, { recursive: true });
    const todo = manifest.mods.filter((m) => {
      const cur = ui.mods.find((x) => x.name === m.name);
      return !cur || cur.status !== 'ok';
    });
    const totalBytes = todo.reduce((a, m) => a + m.size, 0) || 1;
    let doneBytes = 0;
    for (let i = 0; i < todo.length; i++) {
      const m = todo[i];
      const cur = ui.mods.find((x) => x.name === m.name);
      if (cur) cur.status = 'dl';
      const dest = path.join(p.modsDir, m.name);
      const part = dest + '.part';
      let lastErr = null;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          await core.downloadFile(m.url, part, {
            expectedSha: m.sha256,
            expectedSize: m.size,
            onProgress: (got) => {
              const pct = Math.min(100, Math.round(((doneBytes + got) / totalBytes) * 100));
              ui.progress = { pct, msg: `Téléchargement ${i + 1}/${todo.length} : ${m.name}` };
              push();
            },
          });
          fs.renameSync(part, dest);
          lastErr = null;
          break;
        } catch (e) {
          lastErr = e;
          try { fs.unlinkSync(part); } catch (_) { /* rien */ }
        }
      }
      if (lastErr) throw new Error(`${m.name} : ${lastErr.message}`);
      core.recordInstalled(p.modsDir, m, data.installed);
      doneBytes += m.size;
      if (cur) cur.status = 'ok';
    }
    // retire les anciens mods gérés par le launcher qui ne sont plus au manifeste
    const keep = new Set(manifest.mods.map((m) => m.name));
    const obsolete = Object.keys(data.installed).filter((n) => !keep.has(n));
    if (obsolete.length) {
      await core.removeMods(p.modsDir, obsolete, { retries: 1, delay: 300 });
      obsolete.forEach((n) => delete data.installed[n]);
    }
    if (todo.length) data.lastUpdate = new Date().toLocaleDateString('fr-FR');
    saveData();
  } catch (e) {
    ui.error = 'Téléchargement interrompu : ' + e.message;
  }
  busy = false;
  ui.progress = null;
  await computeMods();
  push(true);
}

function doPlay() {
  if (ui.update || updating || busy || playing || !manifest || !data.gamePath) return;
  if (ui.mods.some((m) => m.status !== 'ok')) return;
  const p = core.paths(data.gamePath);
  if (!fs.existsSync(p.exe)) { ui.error = 'SCUM.exe est introuvable. Choisissez le dossier du jeu dans les paramètres.'; push(true); return; }
  try {
    const child = spawn(p.exe, CFG.launchArgs, { cwd: path.dirname(p.exe), detached: true, stdio: 'ignore' });
    child.on('error', (e) => { ui.error = 'Impossible de lancer SCUM : ' + e.message; playing = false; clearInterval(monitor); push(true); });
    child.unref();
  } catch (e) {
    ui.error = 'Impossible de lancer SCUM : ' + e.message;
    push(true);
    return;
  }
  ui.error = null;
  playing = true;
  data.sessionActive = data.mode === 'session';
  saveData();
  startMonitor();
  push(true);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1240, height: 800, minWidth: 1000, minHeight: 700,
    frame: false, backgroundColor: '#070807', show: false,
    title: 'Paradis Perdu Launcher',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true,
    },
  });
  win.setMenuBarVisibility(false);
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.on('close', (e) => {
    // En session unique, le launcher reste en arrière-plan jusqu'à la fermeture de SCUM
    if (playing && data.mode === 'session' && !quitWhenDone) { e.preventDefault(); quitWhenDone = true; win.hide(); }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

function wireIpc() {
  ipcMain.handle('init', async () => {
    if (!booted) { booted = true; await boot(); } else { await refresh(); }
    return snapshot();
  });
  ipcMain.handle('setMode', (_e, mode) => {
    if (busy || playing || updating) return snapshot();
    data.mode = mode === 'session' ? 'session' : 'join';
    saveData();
    push(true);
    return snapshot();
  });
  ipcMain.handle('setName', (_e, n) => {
    data.pseudo = String(n || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 20);
    saveData();
    return data.pseudo;
  });
  ipcMain.handle('detect', async () => {
    const g = await core.detectGame();
    if (g) { data.gamePath = g; ui.error = null; saveData(); await computeMods(); } else {
      ui.error = 'SCUM est introuvable dans vos bibliothèques Steam. Utilisez « Parcourir ».';
    }
    push(true);
    return snapshot();
  });
  ipcMain.handle('pick', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Dossier du jeu SCUM', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return snapshot();
    const root = core.normalizeGameRoot(r.filePaths[0]);
    if (!root) {
      ui.error = 'Ce dossier ne contient pas SCUM\\Binaries\\Win64\\SCUM.exe. Choisissez le dossier « SCUM » de Steam.';
    } else {
      data.gamePath = root; ui.error = null; saveData(); await computeMods();
    }
    push(true);
    return snapshot();
  });
  ipcMain.handle('updateLauncher', async () => { await doUpdateLauncher(); return snapshot(); });
  ipcMain.handle('update', async () => { await doUpdate(); return snapshot(); });
  ipcMain.handle('play', () => { doPlay(); return snapshot(); });
  ipcMain.handle('ext', (_e, key) => {
    const url = key === 'discord' ? CFG.discordUrl : key === 'shop' ? CFG.shopUrl : key === 'vote' ? CFG.voteUrl : null;
    if (url && url.startsWith('https://') && !/REMPLACER/i.test(url)) shell.openExternal(url);
  });
  ipcMain.on('win', (_e, action) => {
    if (!win) return;
    if (action === 'min') win.minimize();
    if (action === 'close') win.close();
  });
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (!win.isVisible()) win.show(); if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    loadData();
    wireIpc();
    createWindow();
  });
  app.on('window-all-closed', () => { if (!(playing && data.mode === 'session')) app.quit(); });
}
