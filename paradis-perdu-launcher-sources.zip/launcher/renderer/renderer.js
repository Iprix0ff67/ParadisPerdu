'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const lab = { ok: 'À jour', old: 'Mise à jour', new: 'À installer', dl: 'Téléchargement…' };
const HELP = { join: 'Les mods restent installés.', session: 'Mods supprimés à la fermeture du jeu.' };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1) + ' Go' : Math.max(0.1, b / 1e6).toFixed(b >= 1e8 ? 0 : 1) + ' Mo');
const NEWS0 = { title: 'Bienvenue sur Paradis Perdu !', text: 'Un seul bouton pour tout mettre à jour. Les mods sont récupérés directement depuis notre GitHub.' };
let S = null;

function go(v) {
  $$('.view').forEach((s) => s.classList.toggle('on', s.id === 'v-' + v));
  $$('.nav button[data-v]').forEach((b) => (b.dataset.v === v ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
}

function render(s) {
  if (!s) return;
  S = s;
  const ok = s.mods.filter((m) => m.status === 'ok').length;

  $('#mods').innerHTML = s.mods.map((m) =>
    `<li><span>${esc(m.name)}<em>v${esc(m.version)} · ${fmt(m.size)}</em></span><span class="st ${m.status}">${lab[m.status] || ''}</span></li>`).join('')
    || '<li><span>Aucun mod chargé</span></li>';
  $('#count').textContent = !s.hasManifest ? '' : s.pending ? s.pending + ' à télécharger' : 'tout est à jour';

  const sv = s.server;
  const ss = $('#srvState');
  ss.hidden = !sv;
  ss.textContent = sv ? 'EN LIGNE' : '';
  $('#stPl').textContent = sv ? sv.players + ' / ' + sv.max : '-';
  const pg = sv ? sv.ping : s.ping;
  $('#stPing').textContent = pg != null ? pg + ' ms' : '-';
  $('#stOk').textContent = s.hasManifest ? ok + ' / ' + s.mods.length : '-';
  $('#stDl').textContent = s.hasManifest ? (s.pending ? fmt(s.pendingBytes) : 'Aucun') : '-';
  $('#stGame').textContent = s.gameOk ? 'Détecté' : 'Introuvable';
  $('#stGame').classList.toggle('warn', !s.gameOk);

  $$('.seg button').forEach((b) => {
    b.setAttribute('aria-checked', b.dataset.m === s.mode);
    b.disabled = s.busy || s.playing;
  });
  $('#help').textContent = HELP[s.mode];

  const b = $('#play');
  let st; let txt; let dis = false;
  if (!s.ready) { st = 'busy'; txt = 'Chargement…'; dis = true; }
  else if (s.updating) { st = 'busy'; txt = 'Mise à jour du launcher…'; dis = true; }
  else if (s.update && !s.playing && !s.busy) { st = 'launcher'; txt = 'Mettre à jour le launcher'; }
  else if (!s.hasManifest) { st = 'retry'; txt = 'Réessayer'; }
  else if (!s.gameOk) { st = 'find'; txt = 'Localiser SCUM'; }
  else if (s.busy) { st = 'busy'; txt = 'Téléchargement…'; dis = true; }
  else if (s.playing) { st = 'busy'; txt = 'En jeu'; dis = true; }
  else if (s.pending) { st = 'update'; txt = 'Mettre à jour'; }
  else { st = 'play'; txt = 'Jouer'; }
  b.dataset.s = st; b.textContent = txt; b.disabled = dis;

  // Nouveautés : annonce automatique dès que GitHub contient des mods nouveaux ou modifiés
  const nw = s.news || {};
  let nt; let nx; let nd;
  if (s.update) {
    nt = 'Nouvelle version du launcher : v' + s.update.version;
    nx = 'Cliquez sur « Mettre à jour le launcher ». Tout est automatique, et il est obligatoire pour continuer.';
    nd = 'Important';
  } else if (s.hasManifest && s.pending && ok > 0) {
    nt = 'Mise à jour des mods disponible !';
    nx = s.pending + (s.pending > 1 ? ' mods ont été ajoutés ou modifiés' : ' mod a été ajouté ou modifié')
      + ' sur le serveur. Cliquez sur « Mettre à jour », puis sur « Jouer ».';
    nd = 'Nouveau';
  } else if (s.hasManifest && s.pending) {
    nt = 'Mods à installer';
    nx = 'Les mods du serveur ne sont pas encore installés. Cliquez sur « Mettre à jour », puis sur « Jouer ».';
    nd = '';
  } else {
    nt = nw.title || NEWS0.title;
    nx = nw.text || NEWS0.text;
    nd = nw.date || (s.lastUpdate ? 'Mods mis à jour le ' + s.lastUpdate : '');
  }
  $('#newsTitle').textContent = nt;
  $('#newsText').textContent = nx;
  $('#newsDate').textContent = nd;
  $('#newsDate').classList.toggle('new', nd === 'Nouveau' || nd === 'Important');

  if (document.activeElement !== $('#pseudo')) $('#pseudo').value = s.pseudo || '';
  if (s.version) $('.ver').textContent = 'Launcher v' + s.version;
  $('#path').value = s.gamePath || 'Non trouvé';
  $('#modsDir').value = s.modsDir || '';

  const msg = $('#msg');
  msg.classList.toggle('err', !!s.error);
  let pct = 0;
  if (s.error) msg.textContent = s.error;
  else if (s.update && !s.progress) msg.textContent = 'Launcher v' + s.update.version + ' disponible';
  else if (s.progress) { msg.textContent = s.progress.msg; pct = s.progress.pct; }
  else if (s.playing) { msg.textContent = 'SCUM lancé (' + s.args.join(' ') + ')' + (s.mode === 'session' ? ', mods supprimés à la fermeture' : ''); pct = 100; }
  else if (!s.ready) msg.textContent = 'Chargement…';
  else if (!s.gameOk) msg.textContent = 'Choisissez le dossier de SCUM dans les paramètres';
  else if (s.pending) msg.textContent = 'Mises à jour disponibles';
  else { msg.textContent = 'Prêt à jouer !'; pct = 100; }
  $('#pb').style.width = pct + '%';
  $('#chk').style.visibility = (s.ready && !s.update && s.gameOk && s.hasManifest && !s.pending && !s.busy && !s.error) ? 'visible' : 'hidden';
}

$('#play').addEventListener('click', () => {
  const a = $('#play').dataset.s;
  if (a === 'find') go('set');
  else if (a === 'retry') api.init().then(render);
  else if (a === 'launcher') api.updateLauncher();
  else if (a === 'update') api.update();
  else if (a === 'play') api.play();
});
$$('.seg button').forEach((b) => b.addEventListener('click', () => api.setMode(b.dataset.m)));
$$('[data-v]').forEach((b) => b.addEventListener('click', () => go(b.dataset.v)));
$$('[data-ext]').forEach((b) => b.addEventListener('click', () => api.ext(b.dataset.ext)));
$('#footDiscord').addEventListener('click', () => api.ext('discord'));
$('#footDiscord').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') api.ext('discord'); });
$('#detect').addEventListener('click', async () => {
  $('#setMsg').textContent = 'Recherche en cours…';
  const s = await api.detect(); render(s);
  $('#setMsg').textContent = s.gameOk ? 'SCUM trouvé dans votre bibliothèque Steam.' : '';
});
$('#pick').addEventListener('click', async () => {
  const s = await api.pick(); render(s);
  $('#setMsg').textContent = s.gameOk ? 'Dossier enregistré.' : '';
});
$('#pseudo').addEventListener('input', () => api.setName($('#pseudo').value));
$('#pseudo').addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
$('#wmin').addEventListener('click', () => api.win('min'));
$('#wclose').addEventListener('click', () => api.win('close'));

api.onState(render);
api.init().then(render);
