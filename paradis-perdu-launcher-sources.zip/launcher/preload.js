'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  init: () => ipcRenderer.invoke('init'),
  setMode: (m) => ipcRenderer.invoke('setMode', m),
  detect: () => ipcRenderer.invoke('detect'),
  pick: () => ipcRenderer.invoke('pick'),
  update: () => ipcRenderer.invoke('update'),
  removeMods: () => ipcRenderer.invoke('removeMods'),
  play: () => ipcRenderer.invoke('play'),
  updateLauncher: () => ipcRenderer.invoke('updateLauncher'),
  setName: (n) => ipcRenderer.invoke('setName', n),
  ext: (key) => ipcRenderer.invoke('ext', key),
  win: (action) => ipcRenderer.send('win', action),
  onState: (cb) => ipcRenderer.on('state', (_e, s) => cb(s)),
});
