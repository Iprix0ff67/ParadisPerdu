'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const lab = { ok: 'À jour', old: 'Mise à jour', new: 'À installer', dl: 'Téléchargement…' };
const HELP = { join: 'Les mods restent installés.', session: 'Mods supprimés à la fermeture du jeu.' };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1) + ' Go' : Math.max(0.1, b / 1e6).toFixed(b >= 1e8 ? 0 : 1) + ' Mo');
const NEWS0 = { title: 'Bienvenue sur Paradis Perdu !', text: 'Un seul bouton pour tout mettre à jour. Les mods sont récupérés directement depuis notre GitHub.' };
let S = null;

function go(v) {
  $$('.view').forEach((s) => s.classList.toggle('on', s.id === 'v-' + v));
  $$('.nav button[data-v]').forEach((b) => (b.dataset.v === v ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
}

function render(s) {
  if (!s) return;
  S = s;
  const ok = s.mods.filter((m) => m.status === 'ok').length;
  const nOld = s.mods.filter((m) => m.status === 'old').length;                 // déjà installés mais modifiés : mise à jour
  const nNew = s.mods.filter((m) => m.status !== 'ok' && m.status !== 'old').length; // pas encore installés : installation
  const pl = (n) => n + (n > 1 ? ' mods' : ' mod');

  $('#mods').innerHTML = s.mods.map((m) =>
    `<li><span>${esc(m.name)}<em>v${esc(m.version)} · ${fmt(m.size)}</em></span><span class="st ${m.status}">${lab[m.status] || ''}</span></li>`).join('')
    || '<li><span>Aucun mod chargé</span></li>';
  $('#count').textContent = !s.hasManifest ? '' : s.pending ? s.pending + ' à télécharger' : 'tout est à jour';

  const sv = s.server;
  const ss = $('#srvState');
  ss.hidden = !sv;
  ss.textContent = sv ? 'EN LIGNE' : '';
  $('#stPl').textContent = sv ? sv.players + ' / ' + sv.max : '-';
  const pg = sv ? sv.ping : s.ping;
  $('#stPing').textContent = pg != null ? pg + ' ms' : '-';
  $('#stOk').textContent = s.hasManifest ? ok + ' / ' + s.mods.length : '-';
  $('#stDl').textContent = s.hasManifest ? (s.pending ? fmt(s.pendingBytes) : 'Aucun') : '-';
  $('#stGame').textContent = s.gameOk ? 'Détecté' : 'Introuvable';
  $('#stGame').classList.toggle('warn', !s.gameOk);

  $$('.seg button').forEach((b) => {
    b.setAttribute('aria-checked', b.dataset.m === s.mode);
    b.disabled = s.busy || s.playing;
  });
  $('#help').textContent = HELP[s.mode];

  const inst = s.mods.filter((m) => m.status === 'ok' || m.status === 'old').length;   // mods présents dans ~mods
  const w = $('#wipe');
  w.disabled = !s.ready || s.busy || s.playing || s.updating || !inst;
  w.title = s.playing ? 'Fermez le jeu pour supprimer les mods' : !inst ? 'Aucun mod installé' : 'Supprimer tous les mods installés';
  const b = $('#play');
  let st; let txt; let dis = false;
  if (!s.ready) { st = 'busy'; txt = 'Chargement…'; dis = true; }
  else if (s.updating) { st = 'busy'; txt = 'Mise à jour du launcher…'; dis = true; }
  else if (s.update && s.updateFailed && !s.playing && !s.busy) { st = 'manual'; txt = 'Télécharger le launcher'; }
  else if (s.update && !s.playing && !s.busy) { st = 'launcher'; txt = 'Mettre à jour le launcher'; }
  else if (!s.hasManifest) { st = 'retry'; txt = 'Réessayer'; }
  else if (!s.gameOk) { st = 'find'; txt = 'Localiser SCUM'; }
  else if (s.busy) { st = 'busy'; txt = 'Téléchargement…'; dis = true; }
  else if (s.playing) { st = 'busy'; txt = 'En jeu'; dis = true; }
  else if (s.pending) { st = 'update'; txt = nOld ? 'Mettre à jour' : 'Installer'; }
  else { st = 'play'; txt = 'Jouer'; }
  b.dataset.s = st; b.textContent = txt; b.disabled = dis;

  // Nouveautés : annonce automatique dès que GitHub contient des mods nouveaux ou modifiés
  const nw = s.news || {};
  let nt; let nx; let nd;
  if (s.update && s.updateFailed) {
    nt = 'Mise à jour automatique impossible';
    nx = 'Cliquez sur « Télécharger le launcher », remplacez l\'ancien fichier par le nouveau, puis relancez-le.';
    nd = 'Important';
  } else if (s.update) {
    nt = s.beta ? 'Nouvelle version du launcher' : 'Nouvelle version du launcher : v' + s.update.version;
    nx = 'Cliquez sur « Mettre à jour le launcher ». Tout est automatique, et il est obligatoire pour continuer.';
    nd = 'Important';
  } else if (s.hasManifest && s.pending && ok === 0 && nOld === 0) {
    nt = 'Mods à installer';
    nx = 'Les ' + pl(nNew) + ' du serveur ne sont pas encore installés. Cliquez sur « Installer », puis sur « Jouer ».';
    nd = '';
  } else if (s.hasManifest && s.pending) {
    const go = nOld ? '« Mettre à jour »' : '« Installer »';
    if (nOld && nNew) {
      nt = 'Mise à jour et nouveaux mods !';
      nx = pl(nOld) + (nOld > 1 ? ' ont été mis à jour' : ' a été mis à jour') + ' et ' + pl(nNew) + (nNew > 1 ? ' ont été ajoutés' : ' a été ajouté') + ' sur le serveur.';
    } else if (nOld) {
      nt = 'Mise à jour des mods disponible !';
      nx = pl(nOld) + (nOld > 1 ? ' ont été mis à jour' : ' a été mis à jour') + ' sur le serveur.';
    } else {
      nt = 'Nouveaux mods disponibles !';
      nx = pl(nNew) + (nNew > 1 ? ' ont été ajoutés' : ' a été ajouté') + ' sur le serveur.';
    }
    nx += ' Cliquez sur ' + go + ', puis sur « Jouer ».';
    nd = 'Nouveau';
  } else {
    nt = nw.title || NEWS0.title;
    nx = nw.text || NEWS0.text;
    nd = nw.date || (s.lastUpdate ? 'Mods mis à jour le ' + s.lastUpdate : '');
  }
  $('#newsTitle').textContent = nt;
  $('#newsText').textContent = nx;
  $('#newsDate').textContent = nd;
  $('#newsDate').classList.toggle('new', nd === 'Nouveau' || nd === 'Important');

  if (document.activeElement !== $('#pseudo')) $('#pseudo').value = s.pseudo || '';
  $('.ver').textContent = s.beta ? 'Launcher (Bêta)' : 'Launcher v' + s.version;
  document.documentElement.classList.toggle('maxed', !!s.maxed);
  $('#wmax').textContent = s.maxed ? '❐' : '□';
  $('#wmax').setAttribute('aria-label', s.maxed ? 'Réduire la fenêtre' : 'Agrandir');
  $('#wmax').title = s.maxed ? 'Réduire' : 'Agrandir';
  if ($('#bld')) $('#bld').textContent = 'Version interne ' + (s.version || '');
  $('#path').value = s.gamePath || 'Non trouvé';
  $('#modsDir').value = s.modsDir || '';

  const msg = $('#msg');
  msg.classList.toggle('err', !!s.error);
  let pct = 0;
  if (s.error) msg.textContent = s.error;
  else if (s.update && s.updateFailed) msg.textContent = 'Mise à jour automatique impossible';
  else if (s.update && !s.progress) msg.textContent = s.beta ? 'Mise à jour du launcher disponible' : 'Launcher v' + s.update.version + ' disponible';
  else if (s.progress) { msg.textContent = s.progress.msg; pct = s.progress.pct; }
  else if (s.playing) { msg.textContent = 'SCUM lancé (' + s.args.join(' ') + ')' + (s.mode === 'session' ? ', mods supprimés à la fermeture' : ''); pct = 100; }
  else if (!s.ready) msg.textContent = 'Chargement…';
  else if (!s.gameOk) msg.textContent = 'Choisissez le dossier de SCUM dans les paramètres';
  else if (s.pending) {
    msg.textContent = nOld && nNew ? 'Mise à jour : ' + pl(nOld) + ' · Installation : ' + pl(nNew)
      : nOld ? 'Mise à jour disponible : ' + pl(nOld) : 'Installation disponible : ' + pl(nNew);
  }
  else { msg.textContent = 'Prêt à jouer !'; pct = 100; }
  $('#pb').style.width = pct + '%';
  $('#chk').style.visibility = (s.ready && !s.update && s.gameOk && s.hasManifest && !s.pending && !s.busy && !s.error) ? 'visible' : 'hidden';
}

$('#play').addEventListener('click', () => {
  const a = $('#play').dataset.s;
  if (a === 'find') go('set');
  else if (a === 'retry') api.init().then(render);
  else if (a === 'launcher') api.updateLauncher();
  else if (a === 'manual') api.ext('release');
  else if (a === 'update') api.update();
  else if (a === 'play') api.play();
});
$$('.seg button').forEach((b) => b.addEventListener('click', () => api.setMode(b.dataset.m)));
$$('[data-v]').forEach((b) => b.addEventListener('click', () => go(b.dataset.v)));
$$('[data-ext]').forEach((b) => b.addEventListener('click', () => api.ext(b.dataset.ext)));
$('#footDiscord').addEventListener('click', () => api.ext('discord'));
$('#footDiscord').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') api.ext('discord'); });
$('#detect').addEventListener('click', async () => {
  $('#setMsg').textContent = 'Recherche en cours…';
  const s = await api.detect(); render(s);
  $('#setMsg').textContent = s.gameOk ? 'SCUM trouvé dans votre bibliothèque Steam.' : '';
});
$('#pick').addEventListener('click', async () => {
  const s = await api.pick(); render(s);
  $('#setMsg').textContent = s.gameOk ? 'Dossier enregistré.' : '';
});
$('#pseudo').addEventListener('input', () => api.setName($('#pseudo').value));
$('#pseudo').addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
$('#wmax').addEventListener('click', () => api.win('max'));
$('#wmin').addEventListener('click', () => api.win('min'));
$('#wclose').addEventListener('click', () => api.win('close'));

api.onState(render);
api.init().then(render);

// Supprimer tous les mods (avec confirmation)
$('#wipe').addEventListener('click', () => {
  if (!S || $('#wipe').disabled) return;
  const n = S.mods.filter((m) => m.status === 'ok' || m.status === 'old').length;
  $('#dlgP').textContent = 'Tous les mods du dossier seront supprimés, y compris ceux d\'autres créateurs.';
  $('#dlg').hidden = false; $('#dlgNo').focus();
});
$('#dlgNo').addEventListener('click', () => { $('#dlg').hidden = true; });
$('#dlgYes').addEventListener('click', async () => {
  $('#dlg').hidden = true;
  const r = await window.api.removeMods();
  if (r && r.done) render(r.state || S);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#dlg').hidden = true; });
